#' RStudio Addins
#'
#' Addin to help style your ggplot2 themes
#'
#' @name ggThemeAssist
#' @docType package
#' @import shiny miniUI rstudioapi formatR ggplot2
NULL
